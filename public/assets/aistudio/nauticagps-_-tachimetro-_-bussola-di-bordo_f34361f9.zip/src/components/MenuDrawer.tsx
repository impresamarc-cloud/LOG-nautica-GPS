import React, { useEffect, useState } from 'react';
import { Compass, Download, RotateCcw, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  GpsStatus,
  MarineTelemetryState,
  RouteWaypoint,
  SavedRoute,
  SimulatorControls,
  TelemetrySource,
  WaveFilterLevel,
  WaypointTarget,
} from '../types/marine';
import { formatDuration, formatNauticalCoord } from '../utils/nautical';
import { NauticalWaypointMap } from './NauticalWaypointMap';
import { SimulatorPanel } from './SimulatorPanel';
import { SpeedChart } from './SpeedChart';

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: MarineTelemetryState;
  boatLat: number;
  boatLon: number;
  onClearTrack: () => void;
  routePoints: RouteWaypoint[];
  savedRoutes: SavedRoute[];
  targetBearingDeg: number | null;
  nextLegDistanceNm: number | null;
  totalRouteDistanceNm: number | null;
  onAddRoutePoint: (pt: WaypointTarget) => void;
  onUpdateRoutePoint: (id: string, pt: WaypointTarget) => void;
  onDeleteRoutePoint: (id: string) => void;
  onClearActiveRoute: () => void;
  onSaveCurrentRoute: (name: string) => void;
  onLoadSavedRoute: (route: SavedRoute, reverse?: boolean) => void;
  onDeleteSavedRoute: (id: string) => void;
  source: TelemetrySource;
  onSwitchSource: (next: TelemetrySource) => void;
  waveFilter: WaveFilterLevel;
  onChangeWaveFilter: (level: WaveFilterLevel) => void;
  simControls: SimulatorControls;
  onChangeSimControls: React.Dispatch<React.SetStateAction<SimulatorControls>>;
  onResetTrip: () => void;
  useMagneticWhenStopped: boolean;
  onToggleMagnetic: () => void;
  wakeLockSupported: boolean;
  wakeLockActive: boolean;
  onToggleWakeLock: () => void;
}

export const MenuDrawer: React.FC<MenuDrawerProps> = ({
  isOpen,
  onClose,
  telemetry,
  boatLat,
  boatLon,
  onClearTrack,
  routePoints,
  savedRoutes,
  targetBearingDeg,
  nextLegDistanceNm,
  totalRouteDistanceNm,
  onAddRoutePoint,
  onUpdateRoutePoint,
  onDeleteRoutePoint,
  onClearActiveRoute,
  onSaveCurrentRoute,
  onLoadSavedRoute,
  onDeleteSavedRoute,
  source,
  onSwitchSource,
  waveFilter,
  onChangeWaveFilter,
  simControls,
  onChangeSimControls,
  onResetTrip,
  useMagneticWhenStopped,
  onToggleMagnetic,
  wakeLockSupported,
  wakeLockActive,
  onToggleWakeLock,
}) => {
  const [justReset, setJustReset] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleReset = () => {
    onResetTrip();
    setJustReset(true);
    window.setTimeout(() => setJustReset(false), 1800);
  };

  const getGpsStatusText = () => {
    if (source === TelemetrySource.SIMULATOR) {
      return '▲ Simulatore attivo';
    }
    switch (telemetry.gpsStatus) {
      case GpsStatus.ACTIVE:
        return telemetry.accuracyMeters !== null
          ? `● GPS attivo · ±${Math.round(telemetry.accuracyMeters)} m`
          : '● GPS attivo';
      case GpsStatus.SEARCHING:
        return '▲ Ricerca segnale GPS...';
      case GpsStatus.DENIED:
        return '✖ Permesso GPS negato';
      default:
        return '✖ Segnale GPS assente';
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end touch-auto"
      role="dialog"
      aria-modal="true"
      aria-label="Log nautico gps - Impostazioni e medie"
    >
      {/* Dark Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-xs"
        onClick={onClose}
      />

      {/* Top-Right Menu Panel */}
      <div className="relative z-10 w-full max-w-md sm:max-w-lg h-full overflow-y-auto overscroll-contain bg-zinc-950 border-l border-zinc-800/90 p-4 sm:p-6 space-y-5 text-white">
        {/* Minimal Close Button at Top-Right (No clutter above map) */}
        <div className="flex items-center justify-end pb-1">
          <button
            type="button"
            onClick={onClose}
            aria-label="Chiudi menu"
            className="min-h-[38px] min-w-[38px] rounded-xl border border-zinc-800 bg-black flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Interactive Multi-Point Nautical Chart & GPS Wake Tracker */}
        <NauticalWaypointMap
          boatLat={boatLat}
          boatLon={boatLon}
          boatHeading={telemetry.headingDeg}
          hasRealGpsFix={telemetry.latitude !== null && telemetry.longitude !== null}
          track={telemetry.track}
          onClearTrack={onClearTrack}
          routePoints={routePoints}
          savedRoutes={savedRoutes}
          targetBearingDeg={targetBearingDeg}
          nextLegDistanceNm={nextLegDistanceNm}
          totalRouteDistanceNm={totalRouteDistanceNm}
          speedKnots={telemetry.speedKnots}
          onAddRoutePoint={onAddRoutePoint}
          onUpdateRoutePoint={onUpdateRoutePoint}
          onDeleteRoutePoint={onDeleteRoutePoint}
          onClearActiveRoute={onClearActiveRoute}
          onSaveCurrentRoute={onSaveCurrentRoute}
          onLoadSavedRoute={onLoadSavedRoute}
          onDeleteSavedRoute={onDeleteSavedRoute}
        />

        {/* Reset Button + Duration */}
        <div className="flex items-center justify-between pt-1">
          <span className="font-mono tabular-nums text-xs text-zinc-400">
            Sessione {formatDuration(telemetry.elapsedSeconds)}
          </span>
          <button
            type="button"
            onClick={handleReset}
            className="min-h-[40px] px-4 py-2 text-xs font-semibold rounded-lg bg-white text-black hover:bg-zinc-200 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5 shrink-0" />
            <span>{justReset ? 'Azzerato' : 'Azzera Medie'}</span>
          </button>
        </div>

        {/* Averages, Max & Distance */}
        <div className="grid grid-cols-2 gap-4 rounded-xl border border-zinc-800 bg-black p-4">
          <div>
            <div className="text-xs text-zinc-500">Velocità Media</div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="font-mono tabular-nums text-2xl font-bold text-white">
                {telemetry.avgKnots.toFixed(1)}
              </span>
              <span className="text-xs text-zinc-500">Kn</span>
            </div>
            <div className="font-mono tabular-nums text-xs text-zinc-500">
              {(telemetry.avgKnots * 1.852).toFixed(1)} km/h
            </div>
          </div>

          <div>
            <div className="text-xs text-zinc-500">Velocità Massima</div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="font-mono tabular-nums text-2xl font-bold text-white">
                {telemetry.maxKnots.toFixed(1)}
              </span>
              <span className="text-xs text-zinc-500">Kn</span>
            </div>
            <div className="font-mono tabular-nums text-xs text-zinc-500">
              {(telemetry.maxKnots * 1.852).toFixed(1)} km/h
            </div>
          </div>

          <div className="pt-3 border-t border-zinc-900">
            <div className="text-xs text-zinc-500">Distanza Percorsa</div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="font-mono tabular-nums text-xl font-semibold text-white">
                {telemetry.distanceNm.toFixed(2)}
              </span>
              <span className="text-xs text-zinc-500">NM</span>
            </div>
            <div className="font-mono tabular-nums text-xs text-zinc-500">
              {(telemetry.distanceNm * 1.852).toFixed(2)} km
            </div>
          </div>

          <div className="pt-3 border-t border-zinc-900">
            <div className="text-xs text-zinc-500">Precisione GPS</div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="font-mono tabular-nums text-xl font-semibold text-white">
                {telemetry.accuracyMeters !== null
                  ? `±${Math.round(telemetry.accuracyMeters)}`
                  : '--'}
              </span>
              <span className="text-xs text-zinc-500">m</span>
            </div>
          </div>
        </div>

        {/* Coordinates */}
        <div className="rounded-xl border border-zinc-800 bg-black px-4 py-3 space-y-1">
          <div className="text-xs text-zinc-500">Coordinate Barca</div>
          <div className="font-mono tabular-nums text-xs text-zinc-300 flex flex-col gap-0.5">
            <span>Lat {formatNauticalCoord(telemetry.latitude, true)}</span>
            <span>Lon {formatNauticalCoord(telemetry.longitude, false)}</span>
          </div>
        </div>

        {/* PWA Home Screen Installation Card (Moved below stats, not above map) */}
        {!isInstalled && (isInstallable || isIOS) && (
          <div className="rounded-xl border border-zinc-800 bg-black p-3.5 space-y-2.5">
            <div className="flex items-center justify-between gap-3">
              <div className="text-xs text-zinc-300">
                Aggiungi <strong className="text-white">Log nautico gps</strong> alla schermata Home con l&apos;icona nera <span className="font-mono text-white">00.0</span>
              </div>
              {isInstallable ? (
                <button
                  type="button"
                  onClick={install}
                  className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-white text-black text-xs font-semibold hover:bg-zinc-200 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5 shrink-0" />
                  <span>Installa</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowIOSGuide((v) => !v)}
                  className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-white text-black text-xs font-semibold hover:bg-zinc-200 transition-colors whitespace-nowrap shrink-0"
                >
                  Installa su iOS
                </button>
              )}
            </div>

            {showIOSGuide && isIOS && (
              <p className="text-xs text-zinc-400 pt-2 border-t border-zinc-900">
                1. Tocca il pulsante <strong className="text-white">Condividi</strong> in Safari.{' '}
                2. Seleziona <strong className="text-white">Aggiungi alla schermata Home</strong>.
              </p>
            )}
          </div>
        )}

        {/* Speed Chart */}
        <SpeedChart samples={telemetry.samples} />

        {/* Wave Filter */}
        <div className="space-y-2">
          <div className="text-xs text-zinc-400">Filtro Mare</div>
          <div
            role="group"
            aria-label="Filtro smorzamento onda"
            className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-black border border-zinc-800"
          >
            {(
              [
                { id: WaveFilterLevel.RAW, label: 'Diretto' },
                { id: WaveFilterLevel.MEDIUM, label: 'Medio' },
                { id: WaveFilterLevel.ROUGH, label: 'Forte' },
              ] as const
            ).map((opt) => {
              const active = waveFilter === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeWaveFilter(opt.id)}
                  className={`min-h-[38px] px-2 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-zinc-800 text-white'
                      : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Options */}
        <div className="space-y-2 pt-2 border-t border-zinc-900">
          <button
            type="button"
            onClick={onToggleMagnetic}
            className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-zinc-800 bg-black flex items-center justify-between text-xs text-zinc-300 hover:border-zinc-700 transition-colors"
          >
            <span className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-zinc-400 shrink-0" />
              <span>Bussola magnetica da fermo</span>
            </span>
            <span className="font-mono text-white">
              {useMagneticWhenStopped ? 'ON' : 'OFF'}
            </span>
          </button>

          {wakeLockSupported && (
            <button
              type="button"
              onClick={onToggleWakeLock}
              className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-zinc-800 bg-black flex items-center justify-between text-xs text-zinc-300 hover:border-zinc-700 transition-colors"
            >
              <span className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-zinc-400 shrink-0" />
                <span>Mantieni schermo attivo</span>
              </span>
              <span className="font-mono text-white">
                {wakeLockActive ? 'ON' : 'OFF'}
              </span>
            </button>
          )}
        </div>

        {/* Simulator */}
        <div className="pt-2 border-t border-zinc-900 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400">Modalità Test</span>
            <button
              type="button"
              onClick={() =>
                onSwitchSource(
                  source === TelemetrySource.GPS
                    ? TelemetrySource.SIMULATOR
                    : TelemetrySource.GPS
                )
              }
              className="min-h-[38px] px-3.5 py-1.5 text-xs font-medium rounded-lg border border-zinc-700 bg-zinc-900 text-white hover:bg-zinc-800 transition-colors whitespace-nowrap"
            >
              {source === TelemetrySource.GPS ? 'Simulatore' : 'Torna a GPS'}
            </button>
          </div>

          {source === TelemetrySource.SIMULATOR && (
            <SimulatorPanel
              controls={simControls}
              onChange={onChangeSimControls}
              onExitSimulator={() => onSwitchSource(TelemetrySource.GPS)}
            />
          )}
        </div>
      </div>
    </div>
  );
};
