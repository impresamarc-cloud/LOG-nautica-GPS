import { useCallback, useEffect, useRef, useState } from 'react';
import {
  GpsStatus,
  HeadingOrigin,
  MarineTelemetryState,
  SimulatorControls,
  SpeedSample,
  TelemetrySource,
  TrackPoint,
  WaveFilterLevel,
} from '../types/marine';
import {
  computeTrueBearing,
  haversineDistanceMeters,
  knotsToKmh,
  METERS_PER_NAUTICAL_MILE,
  msToKmh,
  msToKnots,
  normalizeDeg360,
  shortestAngleDelta,
} from '../utils/nautical';

interface FixRecord {
  lat: number;
  lon: number;
  timestamp: number;
  accuracy: number;
}

const MAX_SAMPLES = 60;
const MAX_TRACK_POINTS = 2500;

export function useMarineTelemetry() {
  const [source, setSource] = useState<TelemetrySource>(TelemetrySource.GPS);
  const [waveFilter, setWaveFilter] = useState<WaveFilterLevel>(WaveFilterLevel.MEDIUM);
  const [useMagneticWhenStopped, setUseMagneticWhenStopped] = useState<boolean>(true);
  const [magneticAvailable, setMagneticAvailable] = useState<boolean>(false);
  const [wakeLockActive, setWakeLockActive] = useState<boolean>(false);
  const [wakeLockSupported] = useState<boolean>(
    () => typeof navigator !== 'undefined' && 'wakeLock' in navigator
  );

  const [simControls, setSimControls] = useState<SimulatorControls>({
    targetKnots: 14.6,
    targetHeading: 38,
    seaChop: true,
  });

  const [telemetry, setTelemetry] = useState<MarineTelemetryState>({
    source: TelemetrySource.GPS,
    gpsStatus: GpsStatus.SEARCHING,
    gpsErrorMessage: null,
    speedKnots: 0,
    speedKmh: 0,
    headingDeg: null,
    headingOrigin: HeadingOrigin.NONE,
    accuracyMeters: null,
    latitude: null,
    longitude: null,
    maxKnots: 0,
    avgKnots: 0,
    distanceNm: 0,
    elapsedSeconds: 0,
    lastUpdated: null,
    samples: [],
    track: [],
  });

  // Mutable refs for continuous filtering & trip integration
  const watchIdRef = useRef<number | null>(null);
  const prevFixRef = useRef<FixRecord | null>(null);
  const lastTrackPointRef = useRef<TrackPoint | null>(null);
  const smoothedSpeedMsRef = useRef<number>(0);
  const smoothedHeadingRef = useRef<number | null>(null);
  const magneticHeadingRef = useRef<number | null>(null);
  const sessionStartRef = useRef<number>(Date.now());
  const speedSumKnotsRef = useRef<number>(0);
  const speedCountRef = useRef<number>(0);
  const distanceMetersRef = useRef<number>(0);
  const maxKnotsRef = useRef<number>(0);
  const wakeLockSentinelRef = useRef<WakeLockSentinel | null>(null);

  // Simulator internal state
  const simCurrentKnotsRef = useRef<number>(14.6);
  const simCurrentHeadingRef = useRef<number>(38);
  const simLatRef = useRef<number>(41.1865); // Arcipelago di La Maddalena / Bocche di Bonifacio
  const simLonRef = useRef<number>(9.4125);

  const getAlphaForFilter = useCallback((level: WaveFilterLevel): number => {
    switch (level) {
      case WaveFilterLevel.RAW:
        return 1.0;
      case WaveFilterLevel.MEDIUM:
        return 0.42;
      case WaveFilterLevel.ROUGH:
        return 0.2;
    }
  }, []);

  const clearTrack = useCallback(() => {
    lastTrackPointRef.current = null;
    setTelemetry((prev) => {
      if (prev.latitude !== null && prev.longitude !== null) {
        const seed: TrackPoint = {
          lat: prev.latitude,
          lon: prev.longitude,
          timestamp: Date.now(),
        };
        lastTrackPointRef.current = seed;
        return { ...prev, track: [seed] };
      }
      return { ...prev, track: [] };
    });
  }, []);

  const resetTrip = useCallback(() => {
    sessionStartRef.current = Date.now();
    speedSumKnotsRef.current = 0;
    speedCountRef.current = 0;
    distanceMetersRef.current = 0;
    maxKnotsRef.current = 0;
    lastTrackPointRef.current = null;
    setTelemetry((prev) => {
      const freshTrack: TrackPoint[] =
        prev.latitude !== null && prev.longitude !== null
          ? [{ lat: prev.latitude, lon: prev.longitude, timestamp: Date.now() }]
          : [];
      if (freshTrack.length > 0) {
        lastTrackPointRef.current = freshTrack[0];
      }
      return {
        ...prev,
        maxKnots: prev.speedKnots,
        avgKnots: prev.speedKnots,
        distanceNm: 0,
        elapsedSeconds: 0,
        samples: [],
        track: freshTrack,
      };
    });
  }, []);

  // Request / listen to device magnetic orientation for stationary heading fallback
  const requestMagneticCompass = useCallback(async () => {
    if (typeof window === 'undefined' || !('DeviceOrientationEvent' in window)) {
      return;
    }
    try {
      const DOE = DeviceOrientationEvent as unknown as {
        requestPermission?: () => Promise<'granted' | 'denied'>;
      };
      if (typeof DOE.requestPermission === 'function') {
        const res = await DOE.requestPermission();
        if (res !== 'granted') return;
      }
      setUseMagneticWhenStopped(true);
    } catch {
      // Ignore permission rejection silently
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || !useMagneticWhenStopped) return;

    const handleOrientation = (event: DeviceOrientationEvent) => {
      const webkitHeading = (event as DeviceOrientationEvent & { webkitCompassHeading?: number })
        .webkitCompassHeading;

      let heading: number | null = null;
      if (typeof webkitHeading === 'number' && Number.isFinite(webkitHeading)) {
        heading = normalizeDeg360(webkitHeading);
      } else if (event.absolute && typeof event.alpha === 'number' && Number.isFinite(event.alpha)) {
        heading = normalizeDeg360(360 - event.alpha);
      }

      if (heading !== null) {
        magneticHeadingRef.current = heading;
        setMagneticAvailable(true);
      }
    };

    window.addEventListener('deviceorientationabsolute', handleOrientation as EventListener, true);
    window.addEventListener('deviceorientation', handleOrientation, true);
    return () => {
      window.removeEventListener(
        'deviceorientationabsolute',
        handleOrientation as EventListener,
        true
      );
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, [useMagneticWhenStopped]);

  // Screen Wake Lock management
  const toggleWakeLock = useCallback(async () => {
    if (!wakeLockSupported) return;
    try {
      if (wakeLockSentinelRef.current) {
        await wakeLockSentinelRef.current.release();
        wakeLockSentinelRef.current = null;
        setWakeLockActive(false);
      } else {
        const sentinel = await navigator.wakeLock.request('screen');
        wakeLockSentinelRef.current = sentinel;
        setWakeLockActive(true);
        sentinel.addEventListener('release', () => {
          wakeLockSentinelRef.current = null;
          setWakeLockActive(false);
        });
      }
    } catch {
      setWakeLockActive(false);
    }
  }, [wakeLockSupported]);

  // Session elapsed timer (1 Hz)
  useEffect(() => {
    const timer = window.setInterval(() => {
      const elapsed = Math.floor((Date.now() - sessionStartRef.current) / 1000);
      setTelemetry((prev) => ({
        ...prev,
        elapsedSeconds: elapsed,
      }));
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Real GPS Watch Effect
  useEffect(() => {
    if (source !== TelemetrySource.GPS) {
      if (watchIdRef.current !== null && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      return;
    }

    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setTelemetry((prev) => ({
        ...prev,
        source: TelemetrySource.GPS,
        gpsStatus: GpsStatus.UNAVAILABLE,
        gpsErrorMessage: 'Sensore GPS non supportato su questo browser o dispositivo.',
      }));
      return;
    }

    prevFixRef.current = null;
    setTelemetry((prev) => ({
      ...prev,
      source: TelemetrySource.GPS,
      gpsStatus: GpsStatus.SEARCHING,
      gpsErrorMessage: null,
    }));

    const alpha = getAlphaForFilter(waveFilter);

    const onPosition = (pos: GeolocationPosition) => {
      const { latitude, longitude, speed, heading, accuracy } = pos.coords;
      const now = pos.timestamp || Date.now();
      const prevFix = prevFixRef.current;

      let rawSpeedMs = 0;
      let deltaDistMeters = 0;
      let dtSec = 0;

      if (prevFix) {
        dtSec = (now - prevFix.timestamp) / 1000;
        deltaDistMeters = haversineDistanceMeters(
          prevFix.lat,
          prevFix.lon,
          latitude,
          longitude
        );
      }

      if (speed !== null && Number.isFinite(speed) && speed >= 0) {
        rawSpeedMs = speed;
      } else if (prevFix && dtSec > 0.4 && dtSec < 30) {
        // Reject stationary GPS multipath jitter
        const jitterThreshold = Math.max(2.5, accuracy * 0.35);
        rawSpeedMs = deltaDistMeters > jitterThreshold ? deltaDistMeters / dtSec : 0;
      }

      // Stationary noise gate when moored with weak accuracy
      if (waveFilter !== WaveFilterLevel.RAW && rawSpeedMs < 0.18 && accuracy > 10) {
        rawSpeedMs = 0;
      }

      // Apply EMA wave filter
      const filteredSpeedMs =
        alpha >= 0.99
          ? rawSpeedMs
          : smoothedSpeedMsRef.current + alpha * (rawSpeedMs - smoothedSpeedMsRef.current);
      smoothedSpeedMsRef.current = filteredSpeedMs < 0.04 ? 0 : filteredSpeedMs;

      const currentKnots = msToKnots(smoothedSpeedMsRef.current);
      const currentKmh = msToKmh(smoothedSpeedMsRef.current);

      // Integrate distance if valid boat movement
      const minMoveMeters = Math.max(2.0, accuracy * 0.25);
      if (prevFix && dtSec > 0 && deltaDistMeters >= minMoveMeters && currentKnots >= 0.35) {
        distanceMetersRef.current += deltaDistMeters;
      }

      // Resolve Heading / Course Over Ground (COG)
      let resolvedHeading: number | null = smoothedHeadingRef.current;
      let resolvedOrigin: HeadingOrigin = HeadingOrigin.HELD_LAST;

      if (
        heading !== null &&
        Number.isFinite(heading) &&
        heading >= 0 &&
        currentKnots >= 0.4
      ) {
        resolvedHeading = normalizeDeg360(heading);
        resolvedOrigin = HeadingOrigin.GPS_COG;
      } else if (
        prevFix &&
        deltaDistMeters >= Math.max(3.0, accuracy * 0.35) &&
        currentKnots >= 0.45
      ) {
        resolvedHeading = computeTrueBearing(
          prevFix.lat,
          prevFix.lon,
          latitude,
          longitude
        );
        resolvedOrigin = HeadingOrigin.COMPUTED_COG;
      } else if (useMagneticWhenStopped && magneticHeadingRef.current !== null) {
        resolvedHeading = magneticHeadingRef.current;
        resolvedOrigin = HeadingOrigin.MAGNETIC;
      } else if (smoothedHeadingRef.current === null) {
        resolvedHeading = null;
        resolvedOrigin = HeadingOrigin.NONE;
      }

      // Smooth circular angle update
      if (resolvedHeading !== null) {
        if (smoothedHeadingRef.current === null || alpha >= 0.99) {
          smoothedHeadingRef.current = resolvedHeading;
        } else {
          const deltaAngle = shortestAngleDelta(smoothedHeadingRef.current, resolvedHeading);
          smoothedHeadingRef.current = normalizeDeg360(
            smoothedHeadingRef.current + alpha * deltaAngle
          );
        }
      }

      // Update trip max & moving average
      if (currentKnots > maxKnotsRef.current) {
        maxKnotsRef.current = currentKnots;
      }
      if (currentKnots >= 0.2) {
        speedSumKnotsRef.current += currentKnots;
        speedCountRef.current += 1;
      }
      const avgKnots =
        speedCountRef.current > 0
          ? speedSumKnotsRef.current / speedCountRef.current
          : 0;

      // Save fix for next delta when moved enough or after 2.5s
      if (!prevFix || deltaDistMeters >= 2.5 || dtSec >= 2.5) {
        prevFixRef.current = {
          lat: latitude,
          lon: longitude,
          timestamp: now,
          accuracy,
        };
      }

      const sample: SpeedSample = {
        timestamp: Date.now(),
        knots: currentKnots,
        kmh: currentKmh,
        heading: smoothedHeadingRef.current,
      };

      // Append breadcrumb to GPS boat track when moved past multipath threshold
      let nextTrackPoint: TrackPoint | null = null;
      const lastTp = lastTrackPointRef.current;
      const trackMinMove = Math.max(4.0, accuracy * 0.3);
      if (!lastTp) {
        nextTrackPoint = { lat: latitude, lon: longitude, timestamp: now };
        lastTrackPointRef.current = nextTrackPoint;
      } else {
        const distFromLastTp = haversineDistanceMeters(
          lastTp.lat,
          lastTp.lon,
          latitude,
          longitude
        );
        if (distFromLastTp >= trackMinMove) {
          nextTrackPoint = { lat: latitude, lon: longitude, timestamp: now };
          lastTrackPointRef.current = nextTrackPoint;
        }
      }

      setTelemetry((prev) => ({
        ...prev,
        source: TelemetrySource.GPS,
        gpsStatus: GpsStatus.ACTIVE,
        gpsErrorMessage: null,
        speedKnots: currentKnots,
        speedKmh: currentKmh,
        headingDeg: smoothedHeadingRef.current,
        headingOrigin: resolvedOrigin,
        accuracyMeters: accuracy,
        latitude,
        longitude,
        maxKnots: maxKnotsRef.current,
        avgKnots,
        distanceNm: distanceMetersRef.current / METERS_PER_NAUTICAL_MILE,
        lastUpdated: Date.now(),
        samples: [...prev.samples.slice(-(MAX_SAMPLES - 1)), sample],
        track: nextTrackPoint
          ? [...prev.track.slice(-(MAX_TRACK_POINTS - 1)), nextTrackPoint]
          : prev.track,
      }));
    };

    const onError = (err: GeolocationPositionError) => {
      let status = GpsStatus.ERROR;
      let message = 'Impossibile acquisire il segnale GPS.';

      if (err.code === err.PERMISSION_DENIED) {
        status = GpsStatus.DENIED;
        message =
          'Permesso GPS negato. Abilita la geolocalizzazione nel browser o usa la modalità Simulatore per testare a terra.';
      } else if (err.code === err.POSITION_UNAVAILABLE) {
        status = GpsStatus.UNAVAILABLE;
        message = 'Posizione GPS al momento non disponibile. Verifica la visibilità del cielo.';
      } else if (err.code === err.TIMEOUT) {
        status = GpsStatus.SEARCHING;
        message = 'Ricerca satelliti GPS ad alta precisione in corso...';
      }

      setTelemetry((prev) => ({
        ...prev,
        gpsStatus: status,
        gpsErrorMessage: message,
      }));
    };

    const id = navigator.geolocation.watchPosition(onPosition, onError, {
      enableHighAccuracy: true,
      maximumAge: 0,
      timeout: 12000,
    });
    watchIdRef.current = id;

    return () => {
      navigator.geolocation.clearWatch(id);
      watchIdRef.current = null;
    };
  }, [source, waveFilter, useMagneticWhenStopped, getAlphaForFilter]);

  // Sea-Trial Simulator Effect (5 Hz physics + 1 Hz history log)
  useEffect(() => {
    if (source !== TelemetrySource.SIMULATOR) return;

    let tickCount = 0;
    const dt = 0.2; // 200ms update interval
    const alpha = getAlphaForFilter(waveFilter);

    const interval = window.setInterval(() => {
      tickCount += 1;
      const t = Date.now() / 1000;

      // Smooth boat inertia toward target knots & rudder heading
      simCurrentKnotsRef.current +=
        (simControls.targetKnots - simCurrentKnotsRef.current) * 0.18;
      const headingDelta = shortestAngleDelta(
        simCurrentHeadingRef.current,
        simControls.targetHeading
      );
      simCurrentHeadingRef.current = normalizeDeg360(
        simCurrentHeadingRef.current + headingDelta * 0.22
      );

      // Optional realistic wave surge & yaw oscillation
      const waveKnotsOffset =
        simControls.seaChop && simCurrentKnotsRef.current > 0.3
          ? Math.sin(t * 1.35) * 0.28 + Math.cos(t * 0.65) * 0.14
          : 0;
      const waveYawOffset =
        simControls.seaChop && simCurrentKnotsRef.current > 0.3
          ? Math.sin(t * 0.9) * 1.6 + Math.cos(t * 0.42) * 0.8
          : 0;

      const rawKnots = Math.max(0, simCurrentKnotsRef.current + waveKnotsOffset);
      const rawMs = (rawKnots * METERS_PER_NAUTICAL_MILE) / 3600;

      smoothedSpeedMsRef.current =
        alpha >= 0.99
          ? rawMs
          : smoothedSpeedMsRef.current + alpha * (rawMs - smoothedSpeedMsRef.current);

      const finalKnots = msToKnots(smoothedSpeedMsRef.current);
      const finalKmh = knotsToKmh(finalKnots);
      const finalHeading = normalizeDeg360(simCurrentHeadingRef.current + waveYawOffset);
      smoothedHeadingRef.current = finalHeading;

      // Advance simulated boat WGS84 coordinates along heading
      const stepMeters = smoothedSpeedMsRef.current * dt;
      distanceMetersRef.current += stepMeters;
      const headingRad = (finalHeading * Math.PI) / 180;
      const dLat = (stepMeters * Math.cos(headingRad)) / 111320;
      const dLon =
        (stepMeters * Math.sin(headingRad)) /
        (111320 * Math.cos((simLatRef.current * Math.PI) / 180));
      simLatRef.current += dLat;
      simLonRef.current += dLon;

      if (finalKnots > maxKnotsRef.current) {
        maxKnotsRef.current = finalKnots;
      }
      if (finalKnots >= 0.2) {
        speedSumKnotsRef.current += finalKnots;
        speedCountRef.current += 1;
      }
      const avgKnots =
        speedCountRef.current > 0
          ? speedSumKnotsRef.current / speedCountRef.current
          : 0;

      const curSimLat = simLatRef.current;
      const curSimLon = simLonRef.current;
      let nextSimTrackPt: TrackPoint | null = null;
      const lastTp = lastTrackPointRef.current;
      if (!lastTp) {
        nextSimTrackPt = { lat: curSimLat, lon: curSimLon, timestamp: Date.now() };
        lastTrackPointRef.current = nextSimTrackPt;
      } else if (
        haversineDistanceMeters(lastTp.lat, lastTp.lon, curSimLat, curSimLon) >= 5.0
      ) {
        nextSimTrackPt = { lat: curSimLat, lon: curSimLon, timestamp: Date.now() };
        lastTrackPointRef.current = nextSimTrackPt;
      }

      setTelemetry((prev) => {
        const shouldRecordSample = tickCount % 5 === 0 || prev.samples.length === 0;
        const nextSamples = shouldRecordSample
          ? [
              ...prev.samples.slice(-(MAX_SAMPLES - 1)),
              {
                timestamp: Date.now(),
                knots: finalKnots,
                kmh: finalKmh,
                heading: finalHeading,
              },
            ]
          : prev.samples;

        return {
          ...prev,
          source: TelemetrySource.SIMULATOR,
          gpsStatus: GpsStatus.ACTIVE,
          gpsErrorMessage: null,
          speedKnots: finalKnots,
          speedKmh: finalKmh,
          headingDeg: finalHeading,
          headingOrigin: HeadingOrigin.SIMULATED,
          accuracyMeters: 2.4,
          latitude: curSimLat,
          longitude: curSimLon,
          maxKnots: maxKnotsRef.current,
          avgKnots,
          distanceNm: distanceMetersRef.current / METERS_PER_NAUTICAL_MILE,
          lastUpdated: Date.now(),
          samples: nextSamples,
          track: nextSimTrackPt
            ? [...prev.track.slice(-(MAX_TRACK_POINTS - 1)), nextSimTrackPt]
            : prev.track,
        };
      });
    }, dt * 1000);

    return () => window.clearInterval(interval);
  }, [source, simControls, waveFilter, getAlphaForFilter]);

  const switchSource = useCallback((nextSource: TelemetrySource) => {
    smoothedSpeedMsRef.current = 0;
    lastTrackPointRef.current = null;
    setTelemetry((prev) => ({
      ...prev,
      track: [],
    }));
    setSource(nextSource);
  }, []);

  return {
    telemetry,
    source,
    switchSource,
    waveFilter,
    setWaveFilter,
    simControls,
    setSimControls,
    resetTrip,
    clearTrack,
    useMagneticWhenStopped,
    setUseMagneticWhenStopped,
    magneticAvailable,
    requestMagneticCompass,
    wakeLockActive,
    wakeLockSupported,
    toggleWakeLock,
  };
}
